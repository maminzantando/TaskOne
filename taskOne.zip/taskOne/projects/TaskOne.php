<!DOCTYPE html>
<html lange="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,
    initial-scale=1.0">
    <title>Personal Portfolio Website HTML CSS Only |
     Codehal</title>   
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.googleapis.com/css2?
    family=Poppins:wght@300;400;500;600;700;800;900&
    display=swap' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: courier;
}

.header {
    position: fixed;
    width: 100%;
    padding: 25px 5%;
    display: flex;
    justify-content: space-between;
    align-items: center;

}

.navbar a {
    font-size: 18px;
    color: #ededed;
    text-decoration: none;
    font-weight: 500;
    margin-left: 35px;
    transition: .3s;
}

.navbar a:hover,
.navbar a.active {
    color: #00abf0;
}

.home {
    
    display: flex;
    align-items: center;
    padding: 0 10%;
    background-color:#071a27
}

.home-content {
    max-width: 600px;
}

.home-content .btn-box {
    position: relative;
    display: flex;
    justify-content: space-between;
    width: 345px;
    height: 50px;
}

.btn-box a {
    position: relative;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 150px;
    height: 100%;
    background: #00abf0;
    font-size: 18px;
    color:#081b29;
    text-decoration: none;
    border: 2px solid #00abf0;
    border-radius: 8px;
}

.btn-box a:hover {
    background-color: darkcyan;
}

.social-icons a {
  margin: 0 10px;
}

.social-icons img {
  width: 85px; 
  height: auto;
}

input[type=text], select, textarea {
  width: 50%;
  padding: 10px;
  border: 1px solid blue;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 5px;
  margin-bottom: 20px;
  resize: vertical;
  color: red;
}

input[type=submit] {
  background-color: #00abf0;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: darkcyan;
}

input[type=reset] {
  background-color: #00abf0;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=reset]:hover {
  background-color: darkcyan;
}

.container {
  border-radius: 55px;
  background-color: #071a27;
  padding: 100px;
}

.s{
  
font-size:20px;
margin-left:20px;
}

.button-box{
    position: relative;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    width: 450px;
    height: 50vh;
    background: darkcyan;
    font-size: 18px;
    style="padding: 25px 15%;"
    border: 2px solid #00abf0;
    border-radius: 8px;
    text-decoration: none;
    overflow: hidden;
}

@media only screen and (max-width:800px) {
  /* For tablets: */
  .main {
    width: 80%;
    padding: 0;
  }
  .right {
    width: 100%;
  }
}
@media only screen and (max-width:500px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width: 100%;
  }
}
</style>

<body style="background-color:#071a27; color: white;">

    <header class="header">
        <p class="logo" style="position: relative;font-size: 30px;color: white;"><strong>Ntando</strong></p>

             
        <nav class="navbar">
            <a href="#">Home</a>
            <a href="#About">About</a>
            <a href="#Skills">Skills</a>
            <a href="#Project">Project</a>
            <a href="#Contact">Contact</a>
        </nav>
    </header>  

    <section class="home">
        <div class="home-content">
        <br><br><br><br><br><br><br><br><br><br><br><br>
            <h1 style="font-size: 45px;margin: 15px 0 42px;">Hi, I'm Ntando Maminza</h1>
            
            <p style="font-size: 15px; margin: 15px 0 42px;"> Welcome to my portfolio! I am a software developer.
            <br>Please, feel free to look through my portfolio.</p>
            
            <div class="btn-box">
                <a href="#">Get in touch</a>
                <a href="Ntando.pdf" Download>Resume</a>

                
            </div>
            <br><br><br><br><br><br>
        </div>    



    </section>    

    <br><br>
    <!-- About Section -->

<div id="About">
<br><br><br> 
    <h2 style="padding: 25px 5%;text-align:center;margin-top:5rem;">About Me</h2>

    <p style="max-width: 80%;margin-left:10%;margin-right:5%;text-align:center">I'm an enthusiastic and 
            passionate software developer, with a special affection for turning challenging problems into 
            elegant solutions. In my two years of hands-on practice, my pleasure lies in bringing forth 
            innovative and efficient software applications. Specialized in C#, Java, HTML, CSS and Javascript, 
            always scouting for the latest developing technologies in order to keep touch with the changing tech
            landscape. Collaboration is the key, and I enjoy working closely with cross-functional teams to 
            deliver good quality software in order to meet or even exceed customer expectations. I strongly 
            believe in constant learning and sharing of knowledge.</p>

            <br><br>
            <div class="btn-box" style="max-width: 80%;margin-left:10%;margin-right:5%;text-align:center">
                <a href="Ntando.pdf" style="margin-left:0px;width:auto;height:3rem;hover:red" Download>Download my CV</a>
            </div>
            </br></br></br></br></br></br></br></br></br>
        <!-- Skills Section -->

        </a></br></br></br></br></br></br></br></br></br>
   <div id="Skills">  
   <br><br><br> 
   <h2 style="padding: 25px 15%;">My Skills</h2> 
   
   <div class="social-icons" style="padding: 25px 5%;">
   <p><img src="web.gif" alt="Web"> Web development</p></br></br>
  <p><img src="cg.gif" alt="C-sharp"> C#</p></br></br>
  <p><img src="j.gif" alt="Java"> Java</br></br>
</div> 
<br><br><br>   

<!--projects-->
<div id="Project">
<br><br><br> 
<h2 style="padding: 25px 15%;">My Project</h2>

<div class="button-box" style="margin-left:65px;height:20rem">
    <a href="projects/h.php" style="text-decoration:none;color:white;text-align:center" Download ><h2>Reference Guide</h2><br>
    This website will provide knowledge and skills on how to reference work that is found in any source.<br> 
  <br><h4>Web Design</h4></a>
</div>
</div>

<!-- Contact Section -->
<div class="container" id="Contact">
<br><br><br><br>
<h2 style="padding: 25px 5%;">Contact Me</h2> 
<br>


<table border=2 >

<!--Row -->
<tr>
<td style="width: 23%;"><center><i class="material-icons" style="font-size:50px;color:darkcyan;">email</i> 
<p> maminzantando@gmail.com </p></center></td>

<td style="width: 23%;"><center><i class="material-icons" style="font-size:50px;color:darkcyan;">place</i> 
<p> Braamfontein, Gauteng </p></center></td>

<td style="width: 23%;"><center><i class="material-icons" style="font-size:50px;color:darkcyan;">phone</i> 
<p> 076 653 9564 </p></center></td>

</tr>

</table>

<br><br>

<img src="jorissen.jpg" atl="braam">
<br><br><br><br>

<h3>Contact Form</h3>
<br><br>
  <form>
    <label for="fname">First Name</label><br>
    <input type="text" id="fname" name="firstname" placeholder="Your name.."><br>

    <br><label for="lname">Last Name</label><br>
    <input type="text" id="lname" name="lastname" placeholder="Your last name.."><br>

    <br><label for="email">Email</label><br>
    <input type="text" id="email" name="email" placeholder="Your email.."><br>

    <br><label for="message">Message</label><br>
    <textarea id="message" name="message" placeholder="Write something.." style="height:180px"></textarea><br>

    <input type="submit" value="Submit">
    <input type="reset" value="Reset" action="" reset="" >
  </form>
</div>



<div style="padding:30px;text-align:center;">

<div class="s">
<a class="fa fa-github" data-toggle="tooltip" data-placement="top" title="Github"></a>
<a href="https://www.linkedin.com/feed/?trk=onboarding-landing" style="text-decoration:none;color:white;" class="fa fa-linkedin" data-toggle="tooltip" data-placement="top" title="Linkedin"></a>

<p>Designed and Developed by</p>
<p>Ntando - 2024</p>
</div>
</div>

              
</body>

</html>    